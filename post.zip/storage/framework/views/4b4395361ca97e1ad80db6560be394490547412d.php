

<?php $__env->startSection('content'); ?>


<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="<?php echo e(asset('css/mostrarPost.css')); ?>" rel="stylesheet">
<title>Post</title>
</head>
<body>

    <div id="container">
    <img id="image" src="<?php echo e(asset("$post->url_img")); ?>" />
        <p id="text">
          <?php echo e($post->title); ?>

        </p>
   </div>

    <div class="container">
        <p>Creado: <?php echo e($post->created_at->diffForHumans()); ?> | Ultima Edición: <?php echo e($post->updated_at->diffForHumans()); ?></p>
        <p><?php echo e($post->content); ?></p>
        </div>

        <div class="container">
            <h2>Comentarios</h2>

            <?php if(auth()->guard()->check()): ?>
        <form action="<?php echo e(route("posts.comments.store",$post->id)); ?>" method="post" class="comentarios">
                <?php echo e(csrf_field()); ?>

                <textarea name="coment" class="form-control" id="exampleFormControlTextarea1" rows="3" placeholder="Escribe aqui tu comentario"></textarea><br>
                <button type="submit" class="btn btn-primary">Publicar <i class="fas fa-paper-plane"></i></button>
            </form>
            <?php endif; ?>
            <?php if(auth()->guard()->guest()): ?>
            <h4>Para comentar por favor inicia sessión </h4><a class="btn btn-primary" href="/login">Iniciar Sessión</a>
            <?php endif; ?>

            <br>

            <?php $__empty_1 = true; $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php $counter = 0;
                $button = 0;
            ?>
                <div class="coment">
                <p><?php echo e($comment->comment); ?></p>

                <?php $__empty_2 = true; $__currentLoopData = $post->likes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $like): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>

                <?php if($like->comment_id == $comment->id): ?>

                    <?php $counter ++ ?>
                        <?php if(auth()->guard()->check()): ?>
                        <?php if($like->user_id === auth()->user()->id): ?>
                            <?php $button ++ ?>
                        <?php endif; ?>
                        <?php endif; ?>
                <?php endif; ?>

                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                   <?php $button = 0 ?>

                   <?php endif; ?>
            <?php if(auth()->guard()->check()): ?>
                <?php if($button > 0): ?>
                <form action="<?php echo e(route('posts.comments.likes.destroy',[$post->id, $comment->id,$like->id])); ?>" method="post">
                    <?php echo method_field('DELETE'); ?>
                    <?php echo e(csrf_field()); ?>

                    <button class="btn" style="color:#0074DC "><i class="far fa-thumbs-up"></i> Me Gusta</button>
                </form>
                <?php endif; ?>
                   <?php if($button === 0 ): ?>
                   <form action="<?php echo e(route('posts.comments.likes.store',[$post->id, $comment->id])); ?>" method="post">
                       <?php echo e(csrf_field()); ?>

                           <button class="btn" style="color:#6C6C6C "><i class="far fa-thumbs-up"></i> Me Gusta</button>
                       </form>
                       <?php endif; ?>
            <?php endif; ?>
                <p class="btn" style="cursor: default;"><?php if($button > 0): ?> Tu y <?php endif; ?><?php echo e($counter); ?> Personas deieron Me gusta a este comentario</p>

                <?php if(auth()->guard()->check()): ?>
                <?php if($comment->user_id == auth()->user()->id): ?>
                    <form action="<?php echo e(route('posts.comments.destroy',[$post->id, $comment->id])); ?>" method="post">
                        <?php echo method_field('DELETE'); ?>
                        <?php echo e(csrf_field()); ?>

                    <button class="btn btn-danger"><i class="fas fa-trash-alt"></i> Eliminar Comentario</button>
                </form>
                <?php endif; ?>
                <?php endif; ?>

                    <p><b>Creado por:<?php echo e($comment->user_name); ?> <?php echo e($comment->created_at->diffForHumans()); ?></b> | Ultima edición: <?php echo e($comment->updated_at->diffForHumans()); ?></p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="coment">
                    <p>No hay comentarios se el primero en hacerlo</p>
                </div>
            <?php endif; ?>
            
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jeiss\blo3\resources\views/post.blade.php ENDPATH**/ ?>