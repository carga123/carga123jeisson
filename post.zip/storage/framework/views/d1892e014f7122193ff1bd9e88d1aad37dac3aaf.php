<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<a href="/cuenta/blog/<?php echo e($id_user = auth()->id()); ?>/create">Crear un nuevo post</a>
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <img src="<?php echo e($post->url_img); ?>" alt="<?php echo e($post->title); ?>">
    <h1><?php echo e($post->title); ?></h1>
    <p><?php echo e($post->content); ?></p>
    <p>Creado: <?php echo e($post->created_at); ?> ultima edición: <?php echo e($post->updated_at); ?></p>
<a href="/cuenta/blog/<?php echo e($post->id); ?>/edit">Editar</a>
<a href="/cuenta/blog/<?php echo e($post->id); ?>/delete">Borrar</a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jeiss\blo3\resources\views//cuenta.blade.php ENDPATH**/ ?>