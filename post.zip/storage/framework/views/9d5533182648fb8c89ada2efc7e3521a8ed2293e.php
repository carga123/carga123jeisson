<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Mi Cuenta</title>
    <link href="<?php echo e(asset('css/cuenta.css')); ?>" rel="stylesheet">
</head>
<body>
    
<div class="container">
    <h1>Hola <?php echo e(Auth::user()->name); ?>, Aqui estan tus Post</h1>
    <a class="btn btn-primary newPost" href="/post/create">Crear un nuevo post</a>
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="posts">
        <div class="contenido">

            <div class="post">
                <h1><?php echo e($post->title); ?></h1>
                <p><?php echo e($post->content); ?></p>
            </div>

            <div class="post">
                <img src="<?php echo e($post->url_img); ?>" alt="<?php echo e($post->title); ?>">
                <p>Creado: <?php echo e($post->created_at->diffForHumans()); ?></p>
                <p>Ultima edición: <?php echo e($post->updated_at->diffForHumans()); ?></p>
                <h2>Mas opciones del post</h2>
                <a class="btn btn-primary" href="/post/<?php echo e($post->id); ?>/edit">Editar</a>
            <a class="btn btn-primary bntDelete" href="<?php echo e(route('post.destroy',$post->id)); ?>">Borrar</a>
            </div>

        </div>

</div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jeiss\blo3\resources\views/cuenta.blade.php ENDPATH**/ ?>